<?php
// Text
$_['text_title'] = 'CreditCards Payments';

$_['heading_title'] = 'CreditCards Payments';

// Error Text
$_['general_error'] = 'Unfortunately there was an error processing your Payment transaction. Please try again later.';
$_['button_back'] = 'Back';

?>
