<?php
// Text
$_['text_title'] = 'الدفع اونلاين';

$_['heading_title'] = 'الدفع اونلاين';

// Error Text
$_['general_error'] = 'نعتذر هناك خطأ في اكمال عملية الدفع، يرجى المحاولة لاحقا.';
$_['button_back'] = 'رجوع';

?>
